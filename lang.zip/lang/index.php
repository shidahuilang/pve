<?php
//$str = 'This is an encoded string';
$str = file_get_contents("fq.txt");
echo base64_encode($str);
?>