<?php
// 假设通过 GET 方式获取用户请求参数'my'
if (isset($_GET['my'])) {
    $userParam = $_GET['my'];
    $redisKey = "sjkey_$userParam";

    // 这里假设已经安装并连接好了 Redis
    $redis = new Redis();
    $redis->connect('127.0.0.1', 6379);

    $value = $redis->get($redisKey);
    if ($value === false) {
        $response = array('data' => array('cx' => '未查询到请求数据'));
    } else {
        $response = array('data' => array('cx' => "今日请求 $value 次"));
    }
    header('Content-Type: application/json;charset=utf-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
} 


?>








