<?php
session_start();

// 连接 Redis 服务器
$redis = new Redis();
$redis->connect('127.0.0.1', 6379);  // 根据实际情况修改 Redis 服务器的地址和端口
$qq = $redis->get('qq');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredUsername = $_POST['username'];
    $enteredPassword = $_POST['password'];

    // 从 Redis 中获取用户名和密码
    $storedUsername = $redis->get('username');
    $storedPassword = $redis->get('password');

    // 如果 Redis 中没有值，就设置默认值
    if (!$storedUsername ||!$storedPassword) {
        $redis->set('username', 'admin');
        $redis->set('password','admin');
    }

    // 验证用户名和密码
    if ($storedUsername === $enteredUsername && $storedPassword === $enteredPassword) {
        $_SESSION['logged_in'] = true;
        $_SESSION['login_time'] = time();
        header('Location: admin'); 
        exit;
    } else {
        echo "<script>alert('登录失败，请重试');</script>";
    }

    // 验证完毕后关闭 Redis 连接
    $redis->close();
}
?>
   <!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>登录后台_Phpfqapi</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
    }

    header {
      background-color: #007bff;
      margin: 15px;
      border-radius: 5px;
      color: white;
      padding: 15px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header img {
      height: 50px;
      width: 50px;
      border-radius: 50%;
    }

    header h2 {
      margin: 0;
    }

    form {
      background-color: white;
      border-radius: 5px;
      padding: 15px;
      margin: 15px;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }

    form label {
      display: block;
      margin-bottom: 8px;
      font-size: 10px;
    }

    form input[type="text"], 
    form input[type="password"] {
      width: 90%;
      padding: 8px;
      margin-bottom: 15px;
      border: 1px solid #ced4da;
      border-radius: 4px;
      box-shadow: 0 0 10px #007bff;
      font-size: 14px;
      margin: 0 auto;
    }

    form input[type="submit"] {
      background-color: #007bff;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    }

    form input[type="submit"]:hover {
      background-color: #0056b3;
    }
  </style>
  <script>
    // 自动刷新页面的函数
    function autoRefresh() {
      location.reload();
    }
  </script>
</head>

<body>
  <header>
    <img src="https://q1.qlogo.cn/g?b=qq&nk=<?php echo $qq ?>&s=640" alt="Logo">
    <h2>登录后台</h2>
  </header>

 
  <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
    <label for="username">用户名：</label><br>
    <input type="text" id="username" name="username"><br><br>
    <label for="password">密码：</label><br>
    <input type="password" id="password" name="password"><br><br>
    <input type="submit" value="登录">
  </form>
</body>

</html>  





