<?php
session_start();
// 检查登录状态
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in']!== true || (isset($_SESSION['login_time']) && time() - $_SESSION['login_time'] > 3600)) {
    header('Location: login'); 
    exit;
}
// 连接 Redis 服务器
    $redis = new Redis();
    $redis->connect('127.0.0.1', 6379);
    $qq = $redis->get('qq');
    // 关闭 Redis 连接
    $redis->close();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>后台管理_Phpfqapi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        header {
            background-color: #007bff;
            color: white;
            margin: 15px;
            border-radius: 5px;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header img {
            height: 50px;
            width: 50px;
            border-radius: 50%;
        }

        header h2 {
            margin: 0;
        }


        form {
            background-color: white;
            border-radius: 5px;
            padding: 15px;
            margin: 15px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-size: 10px;
        }

        form input[type="text"] {
            width: 90%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-shadow: 0 0 10px #007bff;
            font-size: 14px;
            margin: 0 auto;
        }

        form input[type="submit"],
        input[type="button"] {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 35px;
            cursor: pointer;
            font-size: 14px;
        }

        form input[type="submit"]:hover,
        input[type="button"]:hover {
            background-color: #0056b3;
        }
        /* 查询结果样式 */
        .key-item {
            background-color: white;
            border-radius: 5px;
            padding: 15px;
            margin: 15px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        /* 悬浮球样式 */
   .floating-ball {
      position: fixed;
      bottom: 20px;
      right: 24px;
      width: 50px;
      height: 50px;
      background-image: url('/static/img/s.png');
      background-size: cover;
      border-radius: 50%;
      cursor: pointer;
     animation: rotate 5s linear infinite;
    }
@keyframes rotate {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
    /* 弹出菜单样式 */
   .popup-menu {
      display: none;
      border-radius: 10px;
      position: fixed;
      bottom: 80px;
      right: 15px;
      background-color: #fff;
      border: 1px solid #ccc;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

   .popup-menu a {
      display: block;
      padding: 10px;
      text-decoration: none;
      color: #333;
    }

   .popup-menu a:hover {
      background-color: #f5f5f5;
    }

/* 以下是新增的样式，用于新功能输入框和开启关闭选择框 */
 .switch-container {
        border: 1px solid #ced4da;
        border-radius: 4px;
        padding: 6px;
        display: flex;
        width: 90%; 
    }

 .switch-container select {
     /* 去除默认的下拉箭头样式 */
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        
        flex: 1;
        padding: 0px;
        border: none;
        outline: none;
        font-size: 14px;
        background-color: transparent; /* 使背景透明，只显示文字 */
    }

    </style>
</head>

<body>
    <header>
        <a href="/"><img src="https://q1.qlogo.cn/g?b=qq&nk=<?php echo $qq ?>aa&s=640" alt="Logo"></a>
        <h2>后台管理</h2>
    </header>
    
    <div class="floating-ball" onclick="togglePopup()"></div>

  <div class="popup-menu">
        <a href="?page=home">基础设置</a>
        <a href="?page=keySettings">请求限制</a>
        <a href="?page=qqph">封神榜单</a>
        <a href="?page=keylb">密钥查询</a>
        <a href="?page=yxszx">账号邮箱</a>
        <a href="?page=gnkg">功能开关</a>
  </div>

  <script>
    function togglePopup() {
      var popup = document.querySelector('.popup-menu');
      if (popup.style.display === 'block') {
        popup.style.display = 'none';
      } else {
        popup.style.display = 'block';
      }
    }
  </script>


    <?php
    // 连接 Redis 服务器
    $redis = new Redis();
    $redis->connect('127.0.0.1', 6379);
    // 定义固定键数组
    $fixedKeys = array('sygxnn', 'sybb', 'sygx', 'qq', 'rqqxz', 'myxzip', 'hcm', 'xzsjkeysm', 'xzsjkey', 'zwsm', 'sy',  'username', 'password', 'xzip', 'xzsm', 'smtp', 'yxzh', 'yxsq');

    // 初始化 Redis 中的键值对，如果不存在则创建，并设置不同的默认值
    if (!empty($fixedKeys)) {
        // 定义包含每个固定键对应默认值的关联数组
        $defaultValues = array(
            'sygx' => '开启',
            'sybb' => '24.09.28',
            'sygxnn' => '番茄书源有更新,新增次数查询,请访问官网更新!',
            'qq' => '865068376',
            'zwsm' => '这里是正文尾部说明',
            'sy' => '点击导入的书源地址',
            'xzip' => '5',
            'xzsm' => '注意你的KEY疑似泄露,一小时内五个不同IP请求,请一个小时以后再来!',
            'smtp' => 'SMTP服务地址',
            'yxzh' => '你的邮箱账号',
            'yxsq' => '授权码非密码',
            'xzsjkey' => '300',
            'xzsjkeysm' => '注意你二十四小时内超过三百次请求',
            'hcm' => '开启',
            'myxzip' => '开启',
            'rqqxz' => '开启',
        );

        // 遍历固定键数组
        foreach ($fixedKeys as $fixedKey) {
            // 检查 Redis 中是否存在当前固定键
            if (!$redis->exists($fixedKey)) {
                // 如果不存在，从默认值数组中获取对应键的默认值，并设置到 Redis 中
                $redis->set($fixedKey, $defaultValues[$fixedKey]);
            }
        }
    }

    // 处理表单提交
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        foreach ($fixedKeys as $fixedKey) {
            if (isset($_POST[$fixedKey])) {
                $redis->set($fixedKey, $_POST[$fixedKey]);
            }
        }
        echo "<script>alert('修改成功');</script>";
    }

    // 根据页面参数加载不同内容
    $page = isset($_GET['page'])? $_GET['page'] : 'home';
    if ($page === 'gnkg') {
      ?>
<form action="<?php echo $_SERVER['PHP_SELF']. '?page='. $page;?>" method="post">
             <label for="new_feature">缓存功能总开关</label><br>
            <div class="switch-container">
                <select id="hcm" name="hcm">
                    <option value="开启" <?php if ($redis->get('hcm') === '开启') echo'selected';?>>开启</option>
                    <option value="关闭" <?php if ($redis->get('hcm') === '关闭') echo'selected';?>>关闭</option>
                </select>
            </div><br>
            
             <label for="new_feature">密钥限制 IP 开关</label><br>
            <div class="switch-container">
                <select id="myxzip" name="myxzip">
                    <option value="开启" <?php if ($redis->get('myxzip') === '开启') echo'selected';?>>开启</option>
                    <option value="关闭" <?php if ($redis->get('myxzip') === '关闭') echo'selected';?>>关闭</option>
                </select>
            </div><br>
             <label for="new_feature">日请求限制总开关</label><br>
            <div class="switch-container">
                <select id="rqqxz" name="rqqxz">
                    <option value="开启" <?php if ($redis->get('rqqxz') === '开启') echo'selected';?>>开启</option>
                    <option value="关闭" <?php if ($redis->get('rqqxz') === '关闭') echo'selected';?>>关闭</option>
                </select>
            </div><br>
            <label for="new_feature">书源更新功能开关</label><br>
            <div class="switch-container">
                <select id="sygx" name="sygx">
                    <option value="开启" <?php if ($redis->get('sygx') === '开启') echo'selected';?>>开启</option>
                    <option value="关闭" <?php if ($redis->get('sygx') === '关闭') echo'selected';?>>关闭</option>
                </select>
            </div><br>
            <input type="submit" value="修改">
        </form>
        
         <?php
    } else if ($page === 'qqph') {
      ?>
      
      
        <?php
    
    // 获取所有以 sjkey_ 开头的键
     $keys = $redis->keys('sjkey_*');
 

// 存储键值对的数组
$keyValuePairs = [];
foreach ($keys as $key) {
    $value = $redis->get($key);
    $keyValuePairs[$key] = $value;
}

// 根据值从大到小排序键值对数组
arsort($keyValuePairs);

// 处理后的键名数组
$processedKeys = [];
$topTenResults = [];
$count = 0;
foreach ($keyValuePairs as $key => $value) {
    if ($count < 5) {
        // 去掉 sjkey_ 前缀，处理后的键名
        $processedKey = str_replace('sjkey_', '', $key);
        $processedKeys[] = $processedKey;
        $topTenResults[] = "<div class='key-item'>用户密钥:". str_replace('sjkey_', '', $key). " 每日请求:$value";
        $count++;
    } else {
        break;
    }
}

// 使用 SCAN 命令遍历所有键值对并查找匹配值的键名，同时保持顺序
$iterator = null;
$matchCount = 0;
do {
    $scanResult = $redis->scan($iterator);
    foreach ($scanResult as $currentKey) {
        $currentValue = $redis->get($currentKey);
        if (in_array($currentValue, $processedKeys)) {
            $index = array_search($currentValue, $processedKeys);
            $topTenResults[$index].= "<br>键名:$currentKey";

            // 再次以匹配的键为值进行查找
            $nextIterator = null;
            do {
                $nextScanResult = $redis->scan($nextIterator);
                foreach ($nextScanResult as $nextKey) {
                    $nextValue = $redis->get($nextKey);
                    if ($nextValue === $currentKey) {
                        // 提取邮箱部分并格式化
                        $email = $nextKey;
                        $pattern = '/^[a-zA-Z0-9]+@qq.com$/';
                        if (preg_match($pattern, $email)) {
                            $topTenResults[$index].= " 用户邮箱:$email</div>";
                        }
                    }
                }
            } while ($nextIterator!== 0);

            $matchCount++;
        }
    }
} while ($iterator!== 0);

// 输出结果
foreach ($topTenResults as $result) {
    echo $result;
}

    
    
    
   ?>
        <?php
    } else if ($page === 'keySettings') {
      ?>
        <form action="<?php echo $_SERVER['PHP_SELF']. '?page='. $page;?>" method="post">
            <label for="xzsjkey">日请求限制数量</label><br>
            <input type="text" id="xzsjkey" name="xzsjkey" value="<?php echo $redis->get('xzsjkey');?>"><br><br>
            <label for="xzsjkeysm">超过日限制说明</label><br>
            <input type="text" id="xzsjkeysm" name="xzsjkeysm" value="<?php echo $redis->get('xzsjkeysm');?>"><br><br>
            <label for="xzip">密钥限制 IP 数量</label><br>
            <input type="text" id="xzip" name="xzip" value="<?php echo $redis->get('xzip');?>"><br><br>
            <label for="xzsm">密钥已限制说明</label><br>
            <input type="text" id="xzsm" name="xzsm" value="<?php echo $redis->get('xzsm');?>"><br><br>
            <input type="submit" value="修改">
        </form>
       <?php
    } else if ($page === 'keylb') {
      ?>
          <form method="get" id="searchForm">
            <label for="password">输入邮箱查询密钥</label><br>
            <input type="text" name="search_email" placeholder="输入邮箱地址"><br><br>
            <input type="button" value="查询" onclick="performSearch()">
          </form>
          <form method="get" id="valueSearchForm">
            <label for="search_value">输入密钥查询邮箱</label><br>
            <input type="text" name="search_value" placeholder="输入查询密钥"><br><br>
            <input type="button" value="查询" onclick="performValueSearch()">
          </form>
          <form method="post" id="deleteForm">
            <label for="deleteKey">输入键名删除密钥</label><br>
            <input type="text" name="deleteKey" placeholder="请输入键名"><br><br>
            <input type="button" value="删除" onclick="deleteKeyFromRedis()">
          </form>
          <div id="queryResult"></div>
          <script>
            function performSearch() {
                var email = document.querySelector('input[name="search_email"]').value;
                window.location.href = '<?php echo $_SERVER["PHP_SELF"]."?page=keylb&search_email=";?>' + email;
            }

            function deleteKeyFromRedis() {
                var keyToDelete = document.querySelector('input[name="deleteKey"]').value;
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo $_SERVER["PHP_SELF"]."?page=keylb";?>', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        if (xhr.responseText === 'Key deleted successfully.') {
                            alert('成功删除。');
                        } else {
                            alert('成功删除。');
                        }
                    } else {
                        alert('删除失败。');
                    }
                };
                xhr.send('deleteKey=' + keyToDelete);
            }

            function performValueSearch() {
                var valueToFind = document.querySelector('input[name="search_value"]').value;
                window.location.href = '<?php echo $_SERVER["PHP_SELF"]."?page=keylb&search_value=";?>' + valueToFind;
            }
          </script>
        <?php
        if (isset($_GET['search_email'])) {
            $emailToFind = $_GET['search_email'];
            $firstValue = $redis->get($emailToFind);
            if ($firstValue) {
                $resultValue = $redis->get($firstValue);
                if ($resultValue) {
                    echo "<div class='key-item'>查询到 键名: $firstValue 密钥: $resultValue</div>";
                } else {
                    echo "<div class='key-item'>未找到密钥</div>";
                }
            } else {
                echo "<div class='key-item'>未找到密钥</div>";
            }
        }
        if (isset($_POST['deleteKey'])) {
            $keyToDelete = $_POST['deleteKey'];
            if ($redis->exists($keyToDelete)) {
                $redis->del($keyToDelete);
                echo "Key deleted successfully.";
            } else {
                echo "Key not found.";
            }
        }
        if (isset($_GET['search_value'])) {
            $searchValue = $_GET['search_value'];
            $allKeys = $redis->keys('*');
            $foundKey = null;
            foreach ($allKeys as $key) {
                $currentValue = $redis->get($key);
                if ($currentValue === $searchValue) {
                    $foundKey = $key;
                    break;
                }
            }
            if ($foundKey) {
                // 再次查询新键名
                $newFoundKey = null;
                foreach ($allKeys as $key) {
                    $currentValue = $redis->get($key);
                    if ($currentValue === $foundKey) {
                        $newFoundKey = $key;
                        break;
                    }
                }
                if ($newFoundKey) {
                    echo "<div class='key-item'>查询对应邮箱为：$newFoundKey</div>";
                } else {
                    echo "<div class='key-item'>未找到对应邮箱</div>";
                }
            } else {
                echo "<div class='key-item'>未找到对应邮箱</div>";
            }
        }
   ?>
   
      <?php
    } else if ($page === 'yxszx') {
      ?>
      
      <form action="<?php echo $_SERVER['PHP_SELF']. '?page='. $page;?>" method="post">
           <label for="username">请输入管理账号</label><br>
            <input type="text" id="username" name="username" value="<?php echo $redis->get('username');?>"><br><br>
            <label for="password">请输入管理密码</label><br>
            <input type="text" id="password" name="password" value="<?php echo $redis->get('password');?>"><br><br>
            <label for="smtp">设置SMTP服务地址</label><br>
            <input type="text" id="smtp" name="smtp" value="<?php echo $redis->get('smtp');?>"><br><br>
            <label for="yxzh">输入你的邮箱账号</label><br>
            <input type="text" id="yxzh" name="yxzh" value="<?php echo $redis->get('yxzh');?>"><br><br>
           <label for="yxsq">输入你邮箱授权码</label><br>
            <input type="text" id="yxsq" name="yxsq" value="<?php echo $redis->get('yxsq');?>"><br><br>
            <input type="submit" value="修改">
        </form>
      
        <?php
    } else {
       ?>
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
            <label for="sybb">输入书源版本号</label><br>
            <input type="text" id="sybb" name="sybb" value="<?php echo $redis->get('sybb');?>"><br><br>
            <label for="sygxnn">请输入更新内容</label><br>
            <input type="text" id="sygxnn" name="sygxnn" value="<?php echo $redis->get('sygxnn');?>"><br><br>
            <label for="qq">请输入 QQ 号码</label><br>
            <input type="text" id="qq" name="qq" value="<?php echo $redis->get('qq');?>"><br><br>

            <label for="zwsm">正文最后加说明</label><br>
            <input type="text" id="zwsm" name="zwsm" value="<?php echo $redis->get('zwsm');?>"><br><br>
            

            <label for="sy">请输入书源链接</label><br>
            <input type="text" id="sy" name="sy" value="<?php echo $redis->get('sy');?>"><br><br>
            <input type="submit" value="修改">
        </form>
        <?php
    }
   ?>
</body>

</html>






