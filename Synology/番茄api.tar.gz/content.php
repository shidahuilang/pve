<?php
header('Content-Type: application/json; charset=utf-8');
// 连接 Redis 服务器
$redis = new Redis();
$redis->connect('127.0.0.1', 6379);  // 根据实际情况修改 Redis 服务器的地址和端口
// 从 Redis 获取最新的值
$xzip = $redis->get('xzip');
$xzsm = $redis->get('xzsm');
$zwsm = $redis->get('zwsm');
$xzsjkey = $redis->get('xzsjkey');
$xzsjkeysm = $redis->get('xzsjkeysm');
$hcm = $redis->get('hcm');
$myxzip = $redis->get('myxzip');
$rqqxz = $redis->get('rqqxz');
$sygx = $redis->get('sygx');
$sybb = $redis->get('sybb');
$sygxnn = $redis->get('sygxnn');
// 获取用户请求参数中的 key
$userKey = isset($_GET['key'])? $_GET['key'] : '';

// 获取所有以 "key" 开头的键
$redisKeys = $redis->keys('key*');

$found = false;
foreach ($redisKeys as $redisKey) {
    $value = $redis->get($redisKey);
    if ($value === $userKey) {
        $found = true;
        break;
    }
}

if (!$found) {
    $response = [
        'data' => [
            'content' => '未填写密钥,或密钥错误!'
        ]
    ];
    // 设置响应头为 JSON
    header('Content-Type: application/json;charset=utf-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($sygx === "开启") {
    
    if (isset($_GET['version'])) {
    $version = $_GET['version'];
    if ($version!== $sybb) {
    $response = array('data' => array('content' => $sygxnn));
    header('Content-Type: application/json;charset=utf-8');        
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
} else {
    $response = array('data' => array('content' => $sygxnn));
    header('Content-Type: application/json;charset=utf-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

}

if ($rqqxz === "开启") {
    
$sjkey = 'sjkey_'. $userKey;

// 判断 Redis 中是否有该键
if (!$redis->exists($sjkey)) {
    // 如果没有该键，新建并设置默认值为 1，缓存时间为一天（86400 秒）
    $redis->set($sjkey, 1, 86400);
} else {
    // 获取当前键的剩余生存时间
    $ttl = $redis->ttl($sjkey);
    // 值累计向上增加 1
    $redis->incr($sjkey);
    // 重新设置键的生存时间为原来的剩余时间
    $redis->expire($sjkey, $ttl);
}

// 获取剩余生存时间（秒）
$ttlSeconds = $redis->ttl($sjkey);

// 计算剩余小时数
$hours = $ttlSeconds / 3600;
$intHours = floor($hours) + ($hours > 0? 1 : 0);

if ($redis->get($sjkey) >= $xzsjkey) {
    $response = [
        'data' => [
            'content' => $xzsjkeysm.',重置统计剩余时间:'.$intHours.'小时!'
        ]
    ];
    // 设置响应头为 JSON
    header('Content-Type: application/json;charset=utf-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
}

if ($myxzip === "开启") {

// 获取用户的 IP 地址

$userIP = $_SERVER['REMOTE_ADDR'];

// 构建 Redis 键名，用于存储每个 key 的不同 IP 列表

$redisKey = 'ips_key_'. $userKey;

// 获取已缓存的不同 IP 列表及缓存剩余时间
$cachedIPs = $redis->get($redisKey);
$cacheRemainingTime = $redis->ttl($redisKey);

if ($cachedIPs === false) {
    $cachedIPs = $userIP. ' ';
    $redis->set($redisKey, $cachedIPs);
    $redis->expire($redisKey, 3600);  // 设置初始过期时间为 1 小时
} else {
    $ipList = explode(' ', $cachedIPs);
    // 去除重复的 IP
    
    $ipList = array_unique($ipList);

   //设置一个小时几个不同IP

if (count($ipList) >= $xzip){

        $response = [
            'data' => [
                'content' => $xzsm
            ]
        ];
        echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
        
    }

    // 将当前 IP 添加到列表中（如果不存在）
    
    if (!in_array($userIP, $ipList)) {
        $cachedIPs.= $userIP. ' ';
        $redis->set($redisKey, $cachedIPs);

        // 重新设置过期时间为原来的剩余时间
        
        $redis->expire($redisKey, $cacheRemainingTime);
    }
}
}
// 获取当前的 sj 值
$currentValue = $redis->get('sj');

if ($currentValue === false) {
    // 如果不存在，初始化为 0
    $currentValue = 0;
}

// 累加 1
$newValue = $currentValue + 1;

// 存储新的值到 Redis
$redis->set('sj', $newValue);

// 处理日请求（rsj）
$currentDate = date('Y-m-d');
$lastRequestDate = $redis->get('rsj_last_date');

if ($lastRequestDate!== $currentDate) {
    // 如果是新的一天，重置为 0
    $rsjValue = 0;
    $redis->set('rsj_last_date', $currentDate);
} else {
    $rsjValue = $redis->get('rsj');
    if ($rsjValue === false) {
        $rsjValue = 0;
    }
    $rsjValue++;
}

$redis->set('rsj', $rsjValue);

if ($hcm === "开启") {
// 尝试从缓存中获取内容
$cacheKey = 'fanqienovel_content_'. $_GET['item_id'];
$cachedContent = $redis->get($cacheKey);
if ($cachedContent) {
    $response = [
        'data' => [
            'content' => $cachedContent.$zwsm
        ]
    ];
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $redis->close();
    exit;
}
}
//漫画和正文接口,随机选择
$hosts = [
    'novel.snssdk.com',
    'api-sinfonlinec.fanqiesdk.com',
    'api-sinfonlinea.fanqiesdk.com',
    'api-sinfonlineb.fanqiesdk.com'
];
$randomHost = $hosts[array_rand($hosts)];
//音频接口随机选择
$hosts1 = [
    'fanqienovel.com',
    'reading.snssdk.com'
];
$randomHost1 = $hosts1[array_rand($hosts1)];

// 获取用户提交的参数
$parameters = $_GET;

// 检查参数中是否存在 tone_id
if (isset($parameters['tone_id'])) {
    // 如果存在 tone_id，执行相应的代码

    // 获取用户请求参数中的 item_id
$item_id = $_GET['item_id'];

// 获取用户请求参数中的 tone_id
$tone_id = $_GET['tone_id'];

$url = 'https://'.$randomHost1.'/reading/reader/audio/playinfo/?pv_player=-1&aid=1967&tone_id='.$tone_id.'&item_ids='.$item_id;


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

// 请求头
$headers = array(
    "User-Agent: okhttp/3.10.6",
    "y: qian"
);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
curl_close($ch);

// 将响应解码为关联数组
$jsonData = json_decode($response, true);


if (isset($jsonData['data']) && is_array($jsonData['data'])) {
    $jsonData['data'] = ['content' => $jsonData['data'][0]['main_url']];
}

 $result = $jsonData;  
// 移除 log_id 对象
if (isset($result['log_id'])) {
    unset($result['log_id']);
}
if (isset($result['code'])) {
    unset($result['code']);  // 删除 data 键外的 code 键
}
if (isset($result['message'])) {
    unset($result['message']);  // 删除 data 键外的 message 键
}
// 将修改后的数组重新编码为美化后的 JSON
$modified_response = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

// 设置响应头为 JSON，并输出修改后的响应
header('Content-Type: application/json;charset=utf-8');
echo $modified_response;

    
} else {
    // 如果不存在 tone_id，执行正常请求的代码

$item_id = intval($_GET['item_id']);
$url = "https://{$randomHost}/api/novel/book/reader/content/v1/?iid=1&tab_type=3&channel=0&aid=1967&app_name=novelapp&version_code=99999&device_platform=linux&device_type=WSA3&language=zh&os_version=8.1.0";
$data = [
    "item_id" => $item_id,
    "support_image" => 1,
    "y" => "qian"
];
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json"
]);
$response = curl_exec($ch);
$jsonData = json_decode($response, true);
// 处理结果，无论是否有有效数据都进行处理
if (isset($jsonData['data']) && isset($jsonData['data']['content'])) {
    // 净化 HTML 标签,去除头部,去除img无关属性
    $content = preg_replace('/<header[^>]*>.*?<\/header>|img-width=".*?" img-height=".*?" alt=".*?"|amp;|{\!--.*?--}|<p>/s', '', $jsonData['data']['content']);
    $content = preg_replace('/<p\s+idx="[^"]*">|<p class="[^"]*" idx="[^"]*">/', '𓀎', $content.'𓀎');
    $content = str_replace('𓀎',"\n", $content);
    $content = strip_tags($content, '<img>');    
    $result = [
        'data' => [
            'content' => $content.$zwsm
        ]
    ];
} else {
    $result = [
        'data' => [
            'content' => '无法获取有效内容'
        ]
    ];
}

curl_close($ch);

if (isset($jsonData['data']) && isset($jsonData['data']['content']) && stripos($jsonData['data']['content'], 'picInfos')!== false) {
    preg_match_all('/"md5":"([a-f0-9]+)"/', $jsonData['data']['content'], $matches);
    $md5_values = $matches[1];

    // 获取第一个 MD5 值
    $firstMd5 = $md5_values[0];

    // 构建两个 URL
    $url1 = "https://p6-novel.byteimg.com/origin/novel-images/". $firstMd5;
    $url2 = "https://p6-novel.byteimg.com/origin/novel-pic/". $firstMd5;

    // 使用 curl 检查 url1 的响应
    $curl1 = curl_init($url1);
    curl_setopt($curl1, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl1, CURLOPT_SSL_VERIFYPEER, false); // 忽略 SSL 验证（仅用于测试，生产环境不建议）
    curl_setopt($curl1, CURLOPT_CONNECTTIMEOUT, 8); // 设置连接超时时间为 8 秒
    $response1 = curl_exec($curl1);
    curl_close($curl1); // 检测完毕后关闭 curl

    $isNotJsonUrl = '';

    // 注释：检查 url1 的响应是否为 JSON 格式
    // 如果是 JSON 格式，将 $isNotJsonUrl 设置为经过正则处理的 url2
    // 如果不是 JSON 格式，将 $isNotJsonUrl 设置为经过正则处理的 url1
    if (json_decode($response1)) { 
        $isNotJsonUrl = preg_replace('/https:\/\/p6-novel\.byteimg\.com\/origin\/([^\/]+).*/', 'https://p6-novel.byteimg.com/origin/$1/', $url2);
    } else {
        $isNotJsonUrl = preg_replace('/https:\/\/p6-novel\.byteimg\.com\/origin\/([^\/]+).*/', 'https://p6-novel.byteimg.com/origin/$1/', $url1);
    }

    // 将处理后的 URL 添加到每个 MD5 值头部，并使用 img 标签包裹
    for ($i = 0; $i < count($md5_values); $i++) {
        $md5_values[$i] = '<img src="'. $isNotJsonUrl. $md5_values[$i]. '" >';
    }
    $result = array(
       'data' => array(
           'content' => implode('', $md5_values)

       )
    );
}

 // 检查 content 是否包含特定文字
    if (isset($result['data']['content']) && stripos($result['data']['content'], '本节目由番茄畅听出品')!== false) {
        $result = [
            'data' => [
                'content' => '这是音频类型的书籍,他是没有正文的哦!'
            ]
        ];
    }


if ($hcm === "开启") {
// 将处理后的内容存入缓存，并设置一小时的过期时间
$redis->setex($cacheKey, 3600, $content);
}
// 将修改后的数组重新编码为美化后的 JSON
$modified_response = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

// 设置响应头为 JSON，并输出修改后的响应
header('Content-Type: application/json;charset=utf-8');
echo $modified_response;



}
// 关闭 Redis 连接
$redis->close();

?>



