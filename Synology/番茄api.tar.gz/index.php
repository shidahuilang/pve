<?php

// 连接 Redis 服务器
$redis = new Redis();
$redis->connect('127.0.0.1', 6379);  // 根据实际情况修改 Redis 服务器的地址和端口
// 从 Redis 获取值
$sj = $redis->get('sj'); //总请求
$rsj = $redis->get('rsj'); //日请求
$sy = $redis->get('sy'); //书源下载地址

// 关闭 Redis 连接
     $redis->close();

$output = shell_exec('ifconfig eth0 | grep bytes');
preg_match_all('/(RX|TX) packets.*?\((.*?)\)/', $output, $matches);

$results = array();
for ($i = 0; $i < count($matches[1]); $i++) {
    $results[$matches[1][$i]] = $matches[2][$i];
}

// 获取 CPU 使用率
$cpuOutput = [];
exec('ps -eo pcpu | tail -n +2 | awk \'{sum += $1} END {print sum}\'', $cpuOutput);
$cpuUsagePercentage = isset($cpuOutput[0])? $cpuOutput[0] : 0;

// 获取内存信息
$memOutput = [];
exec('free -m', $memOutput);
$totalMemory = 0;
$usedMemory = 0;
foreach ($memOutput as $line) {
    if (strpos($line, 'Mem:') === 0) {
        $parts = preg_split('/\s+/', $line);
        $totalMemory = intval($parts[1]);
        $usedMemory = intval($parts[2]);
        break;
    }
}
$memoryUsagePercentage = ($usedMemory / $totalMemory) * 100;

?>









<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-transform" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge, chrome=1" />
<link rel="icon" href="static/img/y.png" type="image/x-icon"/>
<meta name="description" content="番茄请求接口 - 基于Phpfqapi服务而运行的API网络服务!">
<meta name="keywords" content="番茄书源,番茄接口,番茄API,Phpfqapi">
<title>番茄接口_Phpfqapi</title>
<link rel="icon" href="favicon.ico" />
<link rel="stylesheet" href="static/css/mdui.min.css">
<link rel="stylesheet" href="static/css/font-awesome.min.css">

<style>body{background-image: url("https://dns.jingluo.love/uploads/2024/07/20/wDc3HSgJ_BC9FC3D3-A328-4E2A-8716-C1D702C49800.webp?Expires=1721461556");background-size: cover;background-attachment: fixed;background-position: center;}
           .mdui-card{background: rgba(255,255,255,0.7)!important;transition: background 0.5s;border-radius: 7px;backdrop-filter: blur(5px);box-shadow: 0px 0px 20px 6px rgba(0,0,0,0.12), 0px 0px 20px 6px rgba(0,0,0,0.12);}
           

    .info-item {
            margin: 20px;
            padding: 10px;
    }

       .info-label {
            font-size: 18px;
            font-weight: bold;
        }

       .info-value {
            font-size: 16px;
            margin-top: 5px;
        }

.progress-bar {
            width: 100%;
            height: 20px;
            background-color: rgba(144, 238, 144, 0.5); /* 淡蓝色带透明度 */
            border-radius: 5px;
            margin-top: 10px;
            padding: 2px;
        }

       .progress-container {
            /*background-color: lightblue;*/
            width: 100%;
            height: 20px;
            border-radius: 5px;
            
        
        }

       .progress {
            height: 18px;
            background-color: rgba(255, 0, 0, 0.3); /* 红色带透明度 */
            
            border-radius: 5px;
            
           position: absolute;
           margin: 1px 0px;
        
            
            
        
            
        }
 </style>

</head>
<body class="mdui-theme-primary-black mdui-theme-accent-pink">
<div class="mdui-container mdui-m-t-2">
<div class="mdui-row">
    
    <br>
    <br>
    
<div class="mdui-col-md-6 mdui-col-offset-md-3 mdui-m-b-2">
<div class="mdui-card">
<div class="mdui-card-primary">
<div class="mdui-card-primary-title">数据请求</div>
<div class="mdui-card-primary-subtitle"><?php 
echo '调用  总共：<font color="red">'.$sj.'</font> 次  今日：<font color="red">'.$rsj.'</font> 次' 
?>

<br>
流量  
接收：
<font color="red"><?php echo $results['RX']; ?>
</font>
发送：
<font color="red"><?php echo $results['TX']; ?>
</font> 

</div>
<br>






</div>
</div>
</div>
<div class="mdui-col-md-6 mdui-col-offset-md-3"><div class="mdui-row">
<div class="mdui-col-xs-12 mdui-col-sm-6 mdui-m-b-2">
<div class="mdui-card">
<div class="mdui-card-header">
<img class="mdui-card-header-avatar" src="static/img/y.png" />
<div class="mdui-card-header-title">番茄书源</div>
<div class="mdui-card-header-subtitle">基于 <span class="mdui-text-color-blue">Phpfqapi</span> 接口制作 <font color="red"></font></div>
</div>
<div class="mdui-card-content">
<a href="<?php echo $sy ?>" target="_blank" class="mdui-btn mdui-color-theme-accent mdui-ripple">
     点击导入</a>
</div>
</div>
</div>
<div class="mdui-col-xs-12 mdui-col-sm-6 mdui-m-b-2">
<div class="mdui-card">
<div class="mdui-card-header">
<img class="mdui-card-header-avatar" src="static/img/f.png" />
<div class="mdui-card-header-title">正文接口</div>
<div class="mdui-card-header-subtitle">/content?item_id=书籍ID 需要KEY</div>
</div>
<div class="mdui-card-content">
<a href="/content?item_id=7160365900489556493" target="_blank" class="mdui-btn mdui-color-theme-accent mdui-ripple">
     点击测试</a>
</div>
</div>
</div>


<div class="mdui-col-xs-12 mdui-col-sm-6 mdui-m-b-2">
    <div class="mdui-card">
        <div class="info-item">
       <div class="info-label">核心</div>
        <div class="info-value"><?= $cpuUsagePercentage?>%</div>
        <div class="progress-bar">
            <div class="progress-container">
                <div class="progress" style="width:<?= $cpuUsagePercentage?>%"></div>
            </div>
        </div>
    </div>
  </div>
    </div>
    
<div class="mdui-col-xs-12 mdui-col-sm-6 mdui-m-b-2">
    <div class="mdui-card">
       <div class="info-item">
        <div class="info-label">运存</div>
        <div class="info-value"><?= round($memoryUsagePercentage)?>%</div>
        <div class="progress-bar">
            <div class="progress-container">
                <div class="progress" style="width:<?= round($memoryUsagePercentage)?>%"></div>
            </div>
        </div>
    </div> 
    </div>
    </div>    
    
</div></div>
<div class="mdui-col-md-6 mdui-col-offset-md-3 mdui-m-b-2">
<div class="mdui-card">
<div class="mdui-card-content">为爱发电请勿使用接口下载书籍会封堵!<br>再次感谢 <span class="mdui-text-color-blue">Phpfqapi</span>  浅殇的努力和付出！
</div>
</div>
</div>
</div>
</div>







</body>
</html>