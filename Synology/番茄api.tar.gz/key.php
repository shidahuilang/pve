<?php
session_start();
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// 生成指定长度的随机数字和英文字符组合的字符串
function generateRandomKey($length)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString.= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$hasId = false;
if (isset($_GET['id'])) {
    $hasId = true;
}

// 连接 Redis 服务器
    $redis = new Redis();
    $redis->connect('127.0.0.1', 6379);
    $qq = $redis->get('qq');
    // 关闭 Redis 连接
    $redis->close();
?>
<!DOCTYPE html>
<html>

<head>
    <title>密钥获取_Phpfqapi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

     
     <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        header {
            background-color: #007bff;
            margin: 15px;
            border-radius: 5px;
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header img {
            height: 55px;
            width: 55px;
            border-radius: 50%;
        }

        header h2 {
            margin: 0;
        }

        form {
            background-color: white;
            border-radius: 5px;
            padding: 15px;
            margin: 15px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-size: 10px;
        }

        form input[type="email"] {
            width: 90%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-shadow: 0 0 10px #007bff;
            font-size: 14px;
            margin: 0 auto;
        }

        form input[type="text"] {
            width: 90%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-shadow: 0 0 10px #007bff;
            font-size: 14px;
            margin: 0 auto;
        }

        form input[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        form input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .key-item {
            background-color: white;
            border-radius: 5px;
            padding: 15px;
            margin: 15px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <header>
        <img src="http://q.qlogo.cn/headimg_dl?dst_uin=<?php echo $qq ?>&spec=640&img_type=jpg" alt="Logo">
        <h2>密钥获取</h2>
    </header>
    <?php
    if ($hasId) {
   ?>

        <?php
        // 引入 Redis 扩展
        $redis = new Redis();
        $redis->connect('127.0.0.1', 6379); // 根据实际情况调整 Redis 连接参数

        // 设置 SMTP 邮箱信息
        $host = $redis->get('smtp');
        $yxdz = $redis->get('yxzh');
        $yxmm = $redis->get('yxsq');
        $ljfs = "ssl";
        $dk = 465;

        // 判断是否提交了邮箱地址并请求发送验证码
        if (isset($_POST['send_code']) && isset($_POST['email'])) {
            // 检查是否为 QQ 邮箱
            $isQQEmail = preg_match('/^[0-9a-zA-Z]+@qq.com$/', $_POST['email']);
            if (!$isQQEmail) {
                echo "<div class='key-item'>请使用正确的 QQ 邮箱!</div>";
                exit;
            }

            // 检查 Redis 中是否有此设备
            if ($redis->exists($_GET['id'])) {
                echo "<div class='key-item'>您的设备已申请密钥,请勿重复申请!</div>";
                exit;
            }

            // 检查 Redis 中是否有此邮箱
            if ($redis->exists($_POST['email'])) {
                echo "<div class='key-item'>您已申请密钥,请勿重复申请!</div>";
                exit;
            }

            // 检查是否在一分钟内已发送过验证码
            if (isset($_SESSION['last_send_time']) && (time() - $_SESSION['last_send_time']) < 60) {
                echo "<div class='key-item'>一分钟内只能发送一次验证码，请稍后再试。</div>";
                exit;
            }

            // 生成六位随机数字验证码
            $verificationCode = rand(100000, 999999);

            // 存储验证码和发送时间
            $_SESSION['verification_code'] = $verificationCode;
            $_SESSION['last_send_time'] = time();

            // 使用 PHPMailer 发送邮件
            $mail = new PHPMailer(true);

            try {
                // SMTP 服务器设置
                $mail->isSMTP();
                $mail->Host = $host;
                $mail->SMTPAuth = true;
                $mail->Username = $yxdz;
                $mail->Password = $yxmm;
                $mail->SMTPSecure = $ljfs;
                $mail->Port = $dk;

                // 发件人信息
                $mail->setFrom($yxdz, '大灰狼');

                // 收件人信息
                $mail->addAddress($_POST['email']);

                // 设置字符编码为 UTF-8
                $mail->CharSet = 'UTF-8';

                // 邮件主题和内容
                $mail->Subject = '验证码';
                $mail->Body = "您的验证码是：$verificationCode ，有效期五分钟。";

                $mail->send();
                echo "<div class='key-item'>验证码已发送，请查收。找不到看垃圾箱</div>";
            } catch (Exception $e) {
                echo "<div class='key-item'>发送验证码失败: {$mail->ErrorInfo}</div>";
            }
        }

        // 判断是否提交了验证码进行验证
        if (isset($_POST['verify_code']) && isset($_POST['email'])) {
            // 获取用户输入的验证码
            $userCode = $_POST['verify_code'];

            // 检查验证码是否有效（五分钟内）
            if (isset($_SESSION['verification_code']) && (time() - $_SESSION['last_send_time']) <= 300 && $userCode == $_SESSION['verification_code']) {
                // 获取所有以 key 开头的键
                $keys = $redis->keys('key*');
                $maxNumber = 0;
                foreach ($keys as $existingKey) {
                    $number = intval(substr($existingKey, 3));
                    if ($number > $maxNumber) {
                        $maxNumber = $number;
                    }
                }
                $newKey = 'key'. ($maxNumber + 1);

                // 生成随机数字和英文的 32 位字符
                $randomKey = generateRandomKey(16);

                // 将随机字符存储到新的 Redis 键中
                $redis->set($newKey, $randomKey);

                // 使用 PHPMailer 发送生成的随机字符给验证通过的邮箱
                $mail = new PHPMailer(true);

                try {
                    // SMTP 服务器设置
                    $mail->isSMTP();
                    $mail->Host = $host;
                    $mail->SMTPAuth = true;
                    $mail->Username = $yxdz;
                    $mail->Password = $yxmm;
                    $mail->SMTPSecure = $ljfs;
                    $mail->Port = $dk;

                    // 发件人信息
                    $mail->setFrom($yxdz, '大灰狼');

                    // 收件人信息
                    $mail->addAddress($_POST['email']);

                    // 设置字符编码为 UTF-8
                    $mail->CharSet = 'UTF-8';

                    // 邮件主题和内容
                    $mail->Subject = '获取成功';
                    $mail->Body = "你的密钥：". $randomKey. "";

                    $mail->send();
                    echo "<div class='key-item'>密钥已发送至您的邮箱。找不到看垃圾箱</div>";

                    // 将设备记录到 Redis
                    $redis->set($_GET['id'], $newKey);

                    // 将邮箱记录到 Redis
                    $redis->set($_POST['email'], $newKey);
                } catch (Exception $e) {
                    echo "<div class='key-item'>发送密钥失败: {$mail->ErrorInfo}</div>";
                }

                // 验证通过后清除验证码相关的会话数据
                unset($_SESSION['verification_code'], $_SESSION['last_send_time']);
            } else {
                echo "<div class='key-item'>验证码错误或已过期，请重新获取。</div>";
            }
        }
       ?>

        <form method="post">
            <input type="email" name="email" placeholder="请输入邮箱" required><br><br>
            <input type="submit" name="send_code" value="发送验证">
        </form>
        <form method="post">
            <input type="text" name="verify_code" placeholder="请输入验证码" required>
            <input type="hidden" name="email" value="<?php echo isset($_POST['email'])? $_POST['email'] : '';?>"><br><br>
            <input type="submit" name="verify" value="获取密钥">
        </form>
    <?php
    } else {
   ?>
        <div class='key-item'>请保持最新书源非最新会看到此页面</div>
        <div class='key-item'>在阅读或源阅打开书源登录获取密钥</div>
    <?php
    }
   ?>
</body>

</html>








